<!-- Footer -->
<footer class="main">
	<?php date("Y"); ?>  &copy; <strong>MUT Document Management System</strong>. 
    Developed by 
	<a href="" 
    	target="_blank">Sospeter Mong'are</a>
</footer>
